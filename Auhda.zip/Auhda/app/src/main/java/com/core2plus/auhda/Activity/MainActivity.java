package com.core2plus.auhda.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.core2plus.auhda.API.Responses.auhdaResponse;
import com.core2plus.auhda.API.RetrofitClient;
import com.core2plus.auhda.Adapter.Recycleradapter;
import com.core2plus.auhda.R;
import com.google.firebase.auth.FirebaseAuth;

import org.jsoup.Jsoup;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    List<auhdaResponse> listing;
    Recycleradapter recyclerAdapter;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycle_availableItems);
        listing=new ArrayList<>();
        recyclerAdapter = new Recycleradapter(listing);

    }
    @Override
    protected void onStart() {
        super.onStart();
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
//            Intent intent = new Intent(this, DashboardActivity.class);
//            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//            startActivity(intent);
        }
    }
    private void getAuhdaPosts(){
        Call<List<auhdaResponse>> call= RetrofitClient.getInstance().getApi().getPosts();
        call.enqueue(new Callback<List<auhdaResponse>>() {
            @Override
            public void onResponse(Call<List<auhdaResponse>> call, Response<List<auhdaResponse>> response) {
                List<auhdaResponse> auhdaResponses=response.body();
                if(auhdaResponses!=null){
//            for(int i=0;i<auhdaResponses.size();i++){
                    for(auhdaResponse auhdaResponse : auhdaResponses){
//                if(auhdaResponses.get(i).getTitle()!=null && auhdaResponses.get(i).getContent()!=null ){
//                    String id=auhdaResponses.get(i).getId().toString();
//                    String content=auhdaResponses.get(i).getContent().getRendered().toString();
//                    String date=auhdaResponses.get(i).getDate().toString();
////                    String date2[]=date.split("T");
//                    String date2 =date.replace("T"," ");
//                    String title=auhdaResponses.get(i).getTitle().getRendered().toString();
//                    String a=(content.replace("\\n"," "));
//                    String b=(a.replace("\\r"," "));
//                    String c=(b.replace("\\t"," "));
                        //String ht=Html.fromHtml(c).toString();
                        if(auhdaResponse.getTitle()!=null && auhdaResponse.getContent()!=null ){
                            String id=auhdaResponse.getId().toString();
                            String content=auhdaResponse.getContent().getRendered().toString();
                            String date=auhdaResponse.getDate().toString();
//                    String date2[]=date.split("T");
                            String date2 =date.replace("T"," ");
                            String title=auhdaResponse.getTitle().getRendered().toString();
                            String ht= Jsoup.parse(content).text();
                            Log.v("auhdaID",id);
                            Log.v("auhdaContent",ht);
                            Log.v("auhdaDate",date2);
                            Log.v("auhdaTitle",title);
//                    listing.add(auhdaResponses);
                            listing.add(auhdaResponse);

//                    Set<auhdaResponse> s = new LinkedHashSet<>(listing);


                        }
                        //listing.addAll(auhdaResponses);
                    }
//                recyclerAdapter = new Recycleradapter(listing, ImageLoader.getInstance());
                    RecyclerView.LayoutManager recyce = new LinearLayoutManager(getApplicationContext(), GridLayoutManager.VERTICAL, false);
                    // RecyclerView.LayoutManager recyce = new LinearLayoutManager(MainActivity.this);
                    //recyclerView.addItemDecoration(new GridSpacingdecoration(2, dpToPx(10), true));
                    recyclerView.setLayoutManager(recyce);
                    recyclerView.setItemAnimator(new DefaultItemAnimator());
                    recyclerView.setAdapter(recyclerAdapter);
                }
            }

            @Override
            public void onFailure(Call<List<auhdaResponse>> call, Throwable t) {
                Log.v("auhdaErr",t.getMessage().toString());

            }
        });

    }
}
